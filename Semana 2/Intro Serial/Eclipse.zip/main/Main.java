package main;

import processing.core.PApplet;
import processing.serial.Serial;

public class Main extends PApplet{

	Serial serial;
	int tono = 0;
	
	public static void main(String[] args) {
		PApplet.main("main.Main");
	}
	
	public void settings() {
		size(500,500);
	}

	public void setup() {
		String[] puertos = Serial.list();
		printArray(puertos);
		serial = new Serial(this, puertos[1], 9600);
		serial.bufferUntil('\n');
	}
	
	public void draw() {
		background(255);
		fill(tono, 0 , 0);
		ellipse(width/2, height/2, 100,100);
	}
		
	public void mousePressed() {
		
	}
	
	public void serialEvent(Serial serial) {
		String mensajeRecibido = serial.readStringUntil('\n');
		if(mensajeRecibido != null) {
			mensajeRecibido = mensajeRecibido.trim();
			tono = Integer.parseInt(mensajeRecibido);
			tono /= 4;
			System.out.println(tono);
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
}
