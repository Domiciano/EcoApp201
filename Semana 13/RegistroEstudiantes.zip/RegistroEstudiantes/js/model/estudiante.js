class Estudiante{

    constructor(id, nombre, apellido, codigo){
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.codigo = codigo;
    }

}