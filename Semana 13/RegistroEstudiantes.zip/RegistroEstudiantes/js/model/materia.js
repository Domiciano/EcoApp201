class Materia{
    constructor(id, nombre, profesor){
        this.id = id;
        this.nombre = nombre;
        this.profesor = profesor;
    }
}